const server = require('../app.js');

import {
    test
} from './test';

test(server);