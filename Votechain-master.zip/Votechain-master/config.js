var config = {
    microsoftApiKey: '06b5c355846b4eff8074a08230765499',
    microsoftDetectURL: "https://westcentralus.api.cognitive.microsoft.com/face/v1.0/detect",
    microsoftVerifyURL: 'https://westcentralus.api.cognitive.microsoft.com/face/v1.0/verify',
    mongoURI: 'mongodb://aman:musicstar96@ds127589.mlab.com:27589/votechain'
};

module.exports = config;