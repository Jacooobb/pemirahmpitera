## VoteChain - A Decentralized Voting System using Blockchain and NodeJS


Watch video @ https://youtu.be/9aimIS2vP98